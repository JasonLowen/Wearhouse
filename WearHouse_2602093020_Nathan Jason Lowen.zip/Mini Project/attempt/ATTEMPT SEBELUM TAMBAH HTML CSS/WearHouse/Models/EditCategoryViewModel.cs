﻿namespace WearHouse.Models
{
    public class EditCategoryViewModel
    {
        public Guid Id { get; set; }
        public string CategoryName { get; set; }
    }
}
