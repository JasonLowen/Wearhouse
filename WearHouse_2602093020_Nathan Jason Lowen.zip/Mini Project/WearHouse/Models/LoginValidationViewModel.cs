﻿namespace WearHouse.Models
{
    public class LoginValidationViewModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
